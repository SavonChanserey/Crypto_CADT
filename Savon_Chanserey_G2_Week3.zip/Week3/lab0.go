package main

import (
	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/hex"
	"strings"
	"fmt"
)

func hashMD5(s string) string {
	h := md5.Sum([]byte(s))
	return hex.EncodeToString(h[:])
}

func hashSHA1(s string) string {
	h := sha1.Sum([]byte(s))
	return hex.EncodeToString(h[:])
}

func hashSHA256(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}

func hashSHA512(s string) string {
	h := sha512.Sum512([]byte(s))
	return hex.EncodeToString(h[:])
}

func compareHashes(algorithm, hashA, hashB string) {
	match := strings.EqualFold(hashA, hashB)
	fmt.Printf("\n[%s]\nInput1 Hash: %s\nInput2 Hash: %s\nMatch: %t\n", algorithm, hashA, hashB, match)
}

func main() {
	var input1, input2 string
	fmt.Printf("Enter the first string:")
	fmt.Scan(&input1)
	
	fmt.Printf("Enter the second string:")
	fmt.Scan(&input2)

	fmt.Print("\n=== Hash Comparison Results ===\n")
	
	md5Hash1 := hashMD5(input1)
	md5Hash2 := hashMD5(input2)
	compareHashes("MD5", md5Hash1, md5Hash2)
	
	sha1Hash1 := hashSHA1(input1)
	sha1Hash2 := hashSHA1(input2)
	compareHashes("SHA-1", sha1Hash1, sha1Hash2)

	sha256Hash1 := hashSHA256(input1)
	sha256Hash2 := hashSHA256(input2)
	compareHashes("SHA-256", sha256Hash1, sha256Hash2)
	
	sha512Hash1 := hashSHA512(input1)
	sha512Hash2 := hashSHA512(input2)
	compareHashes("SHA-512", sha512Hash1, sha512Hash2)


}

