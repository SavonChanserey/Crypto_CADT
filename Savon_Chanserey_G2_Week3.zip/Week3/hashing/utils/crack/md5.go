package crack

import (
	"bufio"
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"os"
	"strings"
)

// CrackMD5 iterates over the given wordlist file and tries to match the targetHash.
// If verbose is true it prints each attempt to stdout. If outPath is non-empty, writes verbose lines to that file too.
// Returns (true, password, nil) if found; otherwise (false, "", nil) if not found.
func CrackMD5(wordlistPath, targetHash string, verbose bool, outPath string) (bool, string, error) {
	targetHash = strings.ToLower(strings.TrimSpace(targetHash))

	f, err := os.Open(wordlistPath)
	if err != nil {
		return false, "", fmt.Errorf("failed to open wordlist: %w", err)
	}
	defer f.Close()

	var outFile *os.File
	if outPath != "" {
		of, err := os.Create(outPath)
		if err != nil {
			return false, "", fmt.Errorf("failed to create output file: %w", err)
		}
		outFile = of
		defer outFile.Close()
	}

	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := scanner.Text()
		pw := strings.TrimSpace(line)
		if pw == "" {
			continue
		}

		sum := md5.Sum([]byte(pw))
		hash := hex.EncodeToString(sum[:])

		if verbose {
			lineOut := fmt.Sprintf("Trying: %s -> %s\n", pw, hash)
			fmt.Print(lineOut)
			if outFile != nil {
				_, _ = outFile.WriteString(lineOut)
			}
		}

		if hash == targetHash {
			// If we found it, also write a final line to outFile if present
			foundLine := fmt.Sprintf("FOUND: %s -> %s\n", pw, hash)
			fmt.Print(foundLine)
			if outFile != nil {
				_, _ = outFile.WriteString(foundLine)
			}
			return true, pw, nil
		}
	}

	if err := scanner.Err(); err != nil {
		return false, "", fmt.Errorf("error reading wordlist: %w", err)
	}

	return false, "", nil
}
