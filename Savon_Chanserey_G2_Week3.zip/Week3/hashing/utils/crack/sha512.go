package crack

import (
	"bufio"
	"crypto/sha512"
	"encoding/hex"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"
)

// CrackSHA512 attempts to crack the given sha512 hash using the provided wordlist.
func CrackSHA512(targetHex, wordlistPath string, logger *log.Logger) (string, error) {
	f, err := os.Open(wordlistPath)
	if err != nil {
		return "", fmt.Errorf("open wordlist: %w", err)
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	lineNo := 0
	target := strings.ToLower(strings.TrimSpace(targetHex))

	for scanner.Scan() {
		lineNo++
		word := strings.TrimSpace(scanner.Text())
		if word == "" {
			continue
		}

		h := sha512.Sum512([]byte(word))
		hHex := hex.EncodeToString(h[:])

		if logger != nil && lineNo%10000 == 0 {
			logger.Printf("[sha512] tried %d words — current=%q hash=%s\n", lineNo, word, hHex[:32]) // truncated for verbosity
		}

		if hHex == target {
			if logger != nil {
				logger.Printf("[sha512] match on line %d: %q -> %s\n", lineNo, word, hHex)
			}
			return word, nil
		}
	}

	if err := scanner.Err(); err != nil {
		return "", fmt.Errorf("scan wordlist: %w", err)
	}
	return "", errors.New("not found")
}
