// main.go
package main

import (
	"bufio"
	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/hex"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"time"
)

var supported = map[string]bool{
	"md5":    true,
	"sha1":   true,
	"sha256": true,
	"sha512": true,
}

func computeDigest(mode, s string) string {
	switch mode {
	case "md5":
		sum := md5.Sum([]byte(s))
		return hex.EncodeToString(sum[:])
	case "sha1":
		sum := sha1.Sum([]byte(s))
		return hex.EncodeToString(sum[:])
	case "sha256":
		sum := sha256.Sum256([]byte(s))
		return hex.EncodeToString(sum[:])
	case "sha512":
		sum := sha512.Sum512([]byte(s))
		return hex.EncodeToString(sum[:])
	default:
		return ""
	}
}

// crackFromWordlist scans the given wordlist and returns the plaintext on success.
func crackFromWordlist(mode, targetHash, wordlistPath string, logger *log.Logger) (string, error) {
	f, err := os.Open(wordlistPath)
	if err != nil {
		return "", err
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	// increase buffer in case of very long lines
	const maxCapacity = 10 * 1024 * 1024 // 10MB
	buf := make([]byte, 64*1024)
	scanner.Buffer(buf, maxCapacity)

	line := 0
	for scanner.Scan() {
		line++
		word := scanner.Text()
		digest := computeDigest(mode, word)
		if digest == targetHash {
			logger.Printf("[%s] match on line %d: %q -> %s", mode, line, word, digest)
			return word, nil
		}
	}
	if err := scanner.Err(); err != nil {
		return "", err
	}
	return "", fmt.Errorf("not found")
}

func main() {
	mode := flag.String("mode", "md5", "crack mode: md5 | sha1 | sha256 | sha512")
	hash := flag.String("hash", "", "hash to crack")
	wordlist := flag.String("wordlist", "nord_vpn.txt", "path to wordlist file")
	verboseFile := flag.String("out", "verbose.txt", "file to write verbose output")
	flag.Parse()

	if *hash == "" {
		fmt.Println("Usage: go run main.go -mode md5|sha1|sha256|sha512 -hash <hash> [-wordlist <path>] [-out <verbose.txt>]")
		os.Exit(1)
	}

	if !supported[*mode] {
		fmt.Fprintf(os.Stderr, "unsupported mode: %s\n", *mode)
		os.Exit(1)
	}

	// open verbose output file and set logger to write to both stdout and file
	f, err := os.OpenFile(*verboseFile, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
	if err != nil {
		log.Fatalf("failed to open verbose file: %v", err)
	}
	defer f.Close()

	mw := io.MultiWriter(os.Stdout, f)
	logger := log.New(mw, "", log.LstdFlags)

	logger.Printf("Start cracking: mode=%s hash=%s wordlist=%s", *mode, *hash, *wordlist)
	start := time.Now()

	plaintext, err := crackFromWordlist(*mode, *hash, *wordlist, logger)
	elapsed := time.Since(start)

	if err != nil {
		logger.Printf("Finished in %s — not found: %v", elapsed, err)
		os.Exit(2)
	}

	logger.Printf("SUCCESS: Plaintext = %q (found in %s)", plaintext, elapsed)
}
